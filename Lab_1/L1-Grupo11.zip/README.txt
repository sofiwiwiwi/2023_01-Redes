       |
       / \
      / _ \
     |.o '.|            Integrantes: Javier Pérez Pinto y Sofía Riquelme Flores
     |'._.'|
     |     |
   ,'|  |  |`.
  /  |  |  |  \
  |,-'--|--'-.| 


Consideraciones
Esta tarea fue hecha con pyhton 3.11 y ubuntu 20.04

Ejecución de la tarea:
Para ejecutar la tarea ejecutar en una consola en la carpeta que contenga el archivo "tarea1.py" el siguiente comando

	python3 tarea1.py

  